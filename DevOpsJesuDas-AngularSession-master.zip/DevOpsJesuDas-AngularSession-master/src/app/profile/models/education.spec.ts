import { Education } from './education';

describe('Education', () => {
  it('should create an instance', () => {
    expect(new Education()).toBeTruthy();
  });
});
